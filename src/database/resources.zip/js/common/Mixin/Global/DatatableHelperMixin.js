import DeleteMixin from "./DeleteMixin";
import StatusMixin from "./StatusMixin";

export default {
    mixins: [DeleteMixin, StatusMixin],
}
