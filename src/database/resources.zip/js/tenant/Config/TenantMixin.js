export default {
    computed: {
        currentTenant() {
            return window.tenant
        }
    }
}
