import * as apiUrl from "./ApiUrl";

export default {
    data() {
        return {
            apiUrl
        }
    }
};
