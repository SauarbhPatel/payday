export default class StringMethod {

}
